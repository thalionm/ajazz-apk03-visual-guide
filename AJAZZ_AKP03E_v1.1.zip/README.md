# AJAZZ AKP03E — Scenes and Visual Guide

[English](README.md) · [Português (Brasil)](README.pt-BR.md)

[Download v1.1 — profiles, import assistant, hotkeys and screenshots / Baixar pacote completo](AJAZZ_AKP03E_v1.1.zip?raw=true)

[Installation / Instalação](INSTALL.md) · [Extra icons / Ícones extras](AJAZZ_Extra_Icons.zip?raw=true)

Device shown in AJAZZ: **AKP03E**. Software: **3.10.200.0420**. The repository retains its original APK03 URL.

## Scenes / Cenas

| Scene / Cena | Profile, controls and screenshots / Perfil, controles e prints |
|---|---|
| Canva | [Open / Abrir](scenes/Canva/README.md) |
| Chrome | [Open / Abrir](scenes/Chrome/README.md) |
| Consola de música | [Open / Abrir](scenes/Music-Console/README.md) |
| Controlar Windows | [Open / Abrir](scenes/Windows/README.md) |
| DaVinci Resolve | [Open / Abrir](scenes/DaVinci-Resolve/README.md) |
| Deezer | [Open / Abrir](scenes/Deezer/README.md) |
| Photoshop | [Open / Abrir](scenes/Photoshop/README.md) |
| VLC | [Open / Abrir](scenes/VLC/README.md) |
| WMP | [Open / Abrir](scenes/WMP/README.md) |

## Corrections to v1.0 / Correções da v1.0

- Canva: main knob zoom; bottom buttons Undo / Delete / Redo; Copy is **Ctrl+Shift+C**. / Principal: zoom; botões inferiores Desfazer / Excluir / Refazer.
- Resolve: main knob Left / Right / Space; zoom is lower-left (Ctrl+F5 / Ctrl+F4 / Shift+Z); lower-right Ctrl+F7 / Ctrl+F8 / Ctrl+F.
- Chrome: page 1 main knob volume; page 2 Left / Right / Space. Page-specific mappings are in its folder. / Funções por página na pasta Chrome.
- Windows: Desktop Win+D; Close Alt+F4. / Fechar envia Alt+F4.
- VLC: lower-left Windows Magnifier Win+minus / Win+plus / Win+Esc; lower-right Shift+Left / Shift+Right / F.

The scene tables supersede the generic control map and tentative knob assignments in the original PDFs. Saved and screenshot-confirmed configurations are not hardware-tested. Photoshop and Music Console have exports but no supplied screenshots.

## Original v1.0 archive / Arquivo histórico v1.0

[English PDF — historical](Ajazz_APK03_Visual_Guide_EN.pdf) · [PDF PT-BR — histórico](Guia_Visual_Ajazz_APK03_PT-BR.pdf) · [Original artwork ZIP](Ajazz_APK03_v1.0_EN_PT-BR.zip)

Unofficial personal guide. / Guia pessoal não oficial.
